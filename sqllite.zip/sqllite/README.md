# SQLite Names (Android)

A small Android app (Java + XML + `SQLiteOpenHelper`) that stores names in a local SQLite database and lists them on demand.

## Features

- **Add Name** – validates the input, then saves it to SQLite.
- **Display All Names** – reads every stored name from SQLite and shows it in a list, with a count.
- Friendly messages (inline error + Toast) for every outcome.

## Input validation

| Input | Result |
|---|---|
| Empty / only spaces | "Please enter a name." |
| 1 character | "Name must be at least 2 characters." |
| More than 50 characters | "Name must be at most 50 characters." |
| Digits or symbols (`John123`, `Ann@home`) | "Use letters only …" |
| Already stored (case-insensitive) | "\"Anna\" is already stored." |
| Valid | "\"Anna\" added successfully." and the field is cleared |
| Display with empty database | "The database is empty. Add a name first." |

Leading/trailing spaces are trimmed and repeated spaces are collapsed. Letters from any language are accepted, plus space, `.`, `'` and `-` (so `Mary-Jane`, `O'Brien`, `José`, `അതിര` all work).

## Project structure

```
app/src/main/java/com/example/sqllite/
  MainActivity.java      UI logic (buttons, messages, list)
  DatabaseHelper.java    SQLiteOpenHelper: create table, insert, query
  NameValidator.java     Input validation (plain Java, unit-testable)
app/src/main/res/layout/activity_main.xml
app/src/test/...         NameValidatorTest   (JVM unit tests)
app/src/androidTest/...  DatabaseHelperTest  (emulator/device tests)
```

Database: `names.db`, table `names(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE COLLATE NOCASE)`. All queries are parameterised, so SQL-injection text is stored as plain data.

## Run it

1. Open the folder in Android Studio and let Gradle sync.
2. Run the `app` configuration on an emulator or device (minSdk 24).

## Tests

- Unit tests: `./gradlew testDebugUnitTest`
- Instrumented tests (needs emulator/device): `./gradlew connectedDebugAndroidTest`

## Manual test checklist

1. Tap **Add Name** with an empty box → error shown.
2. Enter `A` → "at least 2 characters".
3. Enter `John123` → "letters only".
4. Enter `Athira` → added; box clears.
5. Enter `athira` → "already stored".
6. Tap **Display All Names** → list shows `Athira`, header says "Stored names (1)".
7. Close and reopen the app, tap **Display All Names** → name is still there (data persisted).
